package com.example.dailyweather

data class Wind(
    val deg: Int,
    val speed: Double
)