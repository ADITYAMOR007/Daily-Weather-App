package com.example.dailyweather

data class Clouds(
    val all: Int
)